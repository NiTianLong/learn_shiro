package com.liwei.shiro.service;

import org.springframework.stereotype.Service;

/**
 * Created by liwei on 16/9/25.
 */
@Service
public class HelloWorld {

    public String hello(String str){
        return str;
    }
}
